
public class Donnees {
	/*
	 * Classe qui doit pouvoir contenir toutes les donn�es d'un tour d'une simulation
	 */
	//probalit� d'avoir un Coop�rant
	private float C=0;
	//matrice des gains
	private int[][] gains;
	//nombres de traitres mis en places au d�but de la simulation
	private int nb_traitres=0;
	
	Donnees(){
	}
	
	//gettes et setters
	
	public float getC() {
		return C;
	}

	public void setC(float c) {
		C = c;
	}

	public int[][] getGains() {
		return gains;
	}

	public void setGains(int[][] gains) {
		this.gains = gains;
	}
	
	public float getB() {
		return (float)gains[1][0]/(float)gains[0][0];
	}

	public int getNb_traitres() {
		return nb_traitres;
	}

	public void setNb_traitres(int nb_traitres) {
		this.nb_traitres = nb_traitres;
	}
	
	
	
}
