import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class GraphiqueSpontannee extends GraphiqueAbs{
	/*
	 * Classe qui as pour but de cr�er un graphique avec une image
	 * mais en ne prenant qu'un set de Donn�es contenants toutes les informations n�cessaires
	 */
	//extremums en x et en y
	public float[] extremums_x;
	
	GraphiqueSpontannee(ParametresGraphique P){
		this.HAUTEUR=P.getHAUTEUR()+taille_legende_haut+taille_legende_bas;
		this.LARGEUR=P.getLARGEUR()+taille_legende_gauche+taille_legende_droite;
		g=(Graphics2D) this.getGraphics();
		
		image=new ImageGraphiqueSpontannee(P,2);
		p=P;
	}
	public void paint(Graphics G) {
		legende(G);
		G.drawImage(image.getImage(),taille_legende_gauche,taille_legende_haut,this);
	}
	protected void legende(Graphics G) {
		//fonction qui doit dessiner la legende � chaque tour aux endroits sp�cifi�es
		//limite de l'image
		G.drawLine(taille_legende_gauche-1,taille_legende_haut,taille_legende_gauche-1,HAUTEUR-taille_legende_bas);
		G.drawLine(taille_legende_gauche-1, HAUTEUR-taille_legende_bas, LARGEUR-taille_legende_droite, HAUTEUR-taille_legende_bas);
		//on dessine le titre de l'axe x au milieu du graphique
		G.drawString(p.getAxe_x(), ((LARGEUR-taille_legende_droite+taille_legende_gauche)/2)-(p.getAxe_x().length()*(5/2)), HAUTEUR);
		//on dessine le titre de l'axe y au milieu du graphique
		G.drawString(p.getAxe_y(), 5, ((HAUTEUR-taille_legende_haut+taille_legende_bas)/2)-(p.getAxe_y().length()*(5/2)));
		//on dessine les extremums de l'axe x
		G.drawString(String.valueOf(extremums_x[0]),taille_legende_gauche,HAUTEUR);
		G.drawString(String.valueOf(extremums_x[1]),LARGEUR-taille_legende_droite-10,HAUTEUR);
		//on dessine les extremums de l'axe y
		G.drawString("1",10,10);
		G.drawString("0",10,HAUTEUR-15);
		//on dessine le Titre
		G.drawString(p.getTitre_graph(), ((LARGEUR-taille_legende_droite+taille_legende_gauche)/2)-(p.getTitre_graph().length()*(5/2)), 10);
	}
	//getters et setters
	public void setExtremums_x(float[] extremums_x) {
		this.extremums_x = extremums_x;
	}
	
	
}
