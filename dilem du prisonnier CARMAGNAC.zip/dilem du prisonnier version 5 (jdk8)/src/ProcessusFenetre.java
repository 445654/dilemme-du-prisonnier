import java.awt.*;
import java.math.*;

public class ProcessusFenetre extends ProcessusAbs{
	Fenetre F;
	
	Dilem[] simulations;
	AnalyseDonn�es[] data;
	
	DessinsCanvas[] canvas_frame;
	ImageCanvas[] images_canvas;
	
	GraphiqueTempReel[] graph_frame;
	ImageGraphiqueTempReel[] images_graph;
	
	
	public void run(){
		//on ini les para des graphiques
		int[] largeurs_G = {200};
		int[] hauteurs_G = {200};
		int[] varnums = {1};
		//titres des diff�rents axes sur les graphiques
		String[] axes_x=duplication_string("nombres d'it�rations",1);
		String[] axes_y=duplication_string("C",1);
		String[] Titres_graph=duplication_string("C en fonction du temps",1);
		//on ini le tableau de parametres graphiques
		ParametresGraphique[] parasGraph=ini_parametres_graphique(largeurs_G,hauteurs_G,varnums,axes_x,axes_y,Titres_graph);
		
		//on ini le temps d'attente
		tps_en_ms=1;
		//on initialise ici les param�tres des canvas explicitements
		float[] exigences_b= generation_para_avec_pas_float(1.75f,3,0.2f);
		int[] largeurs= generation_para_constant(200,3);
		int[] hauteurs= generation_para_constant(200,3);
		int[] algo_gene= generation_para_constant(1,3);
		//ce parametre ne s'applique si on choisi l'algo de gene n�1
		int[] pourcentages_traitres= generation_para_constant(10,3);
		//nombre de tours stock�es utilis�s par les objets AnalyseDonn�es
		int[] nb_tours= generation_para_constant(1,3);
		
		//on initialise le tableau des parametres ddes canvas
		ParametresCanvas[] parasCanvas=ini_parametres_canvas(exigences_b,largeurs,hauteurs,algo_gene,pourcentages_traitres);
		
		//on ini les canvas et les graphiques
		//ini des canvas et de leurs images et les simulations correspondantes
		canvas_frame=new DessinsCanvas[parasCanvas.length];
		images_canvas=new ImageCanvas[parasCanvas.length];
		simulations=new Dilem[parasCanvas.length];
		data=new AnalyseDonn�es[parasCanvas.length];
		
		for (int i=0;i<parasCanvas.length;i++) {
			canvas_frame[i]=new DessinsCanvas(parasCanvas[i]);
			images_canvas[i]=new ImageCanvas(parasCanvas[i]);
			simulations[i]=new Dilem(parasCanvas[i]);
			data[i]=new AnalyseDonn�es(nb_tours[i],parasCanvas[i].getGains());
		}
		//ini des graphiques et de leurs images
		graph_frame=new GraphiqueTempReel[parasGraph.length];
		images_graph=new ImageGraphiqueTempReel[parasGraph.length];
		
		for(int i=0;i<parasGraph.length;i++) {
			graph_frame[i]=new GraphiqueTempReel(parasGraph[i]);
			images_graph[i]=new ImageGraphiqueTempReel(parasGraph[i]);
		}
		//on initalise les composants qui serviront pour la fenetre
		Component[] composants=new Component[canvas_frame.length+graph_frame.length];
		
		//on fait une boucle for un peu bizarre car on a bessoin de faire les ini des canvas et graphiques
		int j=0;
		//boucle pour les composants
		while(j<composants.length) {
			//boucles des graphiques
			for(int i=0;i<graph_frame.length;i++) {
				composants[j]=graph_frame[i];
				j++;
			}
			//boucles des canvas
			for(int i=0;i<canvas_frame.length;i++) {
				composants[j]=canvas_frame[i];
				j++;
			}
			
		}
		
		//on ini la fenetre
		F=new Fenetre(composants);
		//test
		while(F.isVisible()) {
			transfert_donnees();
			repaint_general();
			sleep();
		}
	}
	
	protected void transfert_donnees() {
		//fonction qui doit g�rer les transfert de donn�es entre les diff�rents composants
		/*
		 * Rappel:
		 * 		-un canvas a besoin d'une imageCanvas
		 * 			-imageCanvas a besoin d'une grille de prisonniers de Dilem
		 * 				-Dilem n'as rien besoin
		 * 		-un graphique a besoin d'une imageGraphique
		 * 			-imageGraphique a besoin d'un tab de Donn�es
		 * 				-Chaque Dilem renvoie une Donn�es
		 */
		//variable qui stocke les donnees des simulations du tour
		Donnees[] data_du_tour=new Donnees[simulations.length];
		//variable de transition pour les grilles de prisonniers
		PrisonnierAbs[][] grille_x;
		
		//on profite du processus de transfert des canvas pour recolter les donn�es
		for(int i=0;i<canvas_frame.length;i++) {
			//actualisation des donn�es
			data[i].calculDonnees(simulations[i].getGrille());
			//actualisation des simulations
			simulations[i].tour();
			//on stocke les derni�res donn�es enregistr�es
			data_du_tour[i]=data[i].getLast();
			//on recupere la grille de prisonniers d'une simulation
			grille_x=simulations[i].getGrille();
			//on actualsie l'image
			images_canvas[i].refresh(grille_x);
			//on transfert l'image au canvas
			canvas_frame[i].setImg(images_canvas[i]);
		}
		//processus des graphiques
		for(int i=0;i<graph_frame.length;i++) {
			//on transmet les donn�es a l'image graphique correspondante pour traitement
			images_graph[i].refresh(data_du_tour);
			//on transfert l'image au graphique
			graph_frame[i].setImage(images_graph[i]);
		}
		
	}
	
	private void repaint_general() {
		//fonction qui repaint tout les composants
		for(int i=0;i<canvas_frame.length;i++) {
			canvas_frame[i].repaint();
		}
		for(int i=0;i<graph_frame.length;i++) {
			graph_frame[i].repaint();
		}
	}
}
