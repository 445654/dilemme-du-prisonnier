
public class Main{
	/*
	 * Classe qui gere les eventuelles interactions entre les processus
	 * et les initialises
	 */
	
	public static void main(String[] args) {
		//on cr�e un nouveau processus
		ProcessusAbs p=new ProcessusFenetre();
		//on execute le processus
		p.start();
	}
}
