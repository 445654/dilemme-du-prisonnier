
public class PrisonnierOpportuniste extends PrisonnierAbs{
	
	public PrisonnierOpportuniste(){
		//si l'utilisateur ne met rien on met l'objet dans la configuration de base
		//cad:
		//un croyant
	}
	
	public PrisonnierOpportuniste(int Comportement){
		//on attribue au variables correspondantes leur valeur demand� par l'utilisateur
		comportement=Comportement;
	}
	public int Choix(){
		//on verifie le comportement du joueur et on applique les fonctions correspondantes
		if (comportement == CROYANT) {
			return choix_du_croyant();
		}
		else if (comportement==TRAITRE) {
			return choix_du_traitre();
		}
		else {
			//si on entre un comportement inexact on coop�re syst�matiquement
			return COOPERATION;
		}
	}
	public void stratMaj(PrisonnierAbs[] voisins) {
		//fonction qui va a avoir pour but de d�cider la strat�gie du tour suivant
		/*
		 *Fonction qui prend en entr�e:
		 *le prisonnier dont on change le comportement
		 *ces voisins
		 *et modifie le comportment selon les crit�res suivants:
		 *-le score
		 */
		//on initialise les comportement aux valeurs du joueur
		//pour qu'il ne change pas son comportement si il est le meilleur choix
		this.comportement_futur=comportement;
		float score_maximal=score;
		
		for(int i=0;i<voisins.length;i++) {
			//si le comportment du voisin est meilleur
			if(voisins[i].getScore()>score_maximal) {
				//on change le score maximal
				score_maximal=voisins[i].getScore();
				//on change le comportement optimal
				comportement_futur=voisins[i].getComportement();
			}
		}
	}
	
}
