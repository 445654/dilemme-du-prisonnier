import java.awt.*;

public class ProcessusOff extends ProcessusAbs{
	/*
	 * Classe qui doit tourner en off et ne rendre que dans la console si il trouve une simulation 
	 * qui tend vers un �tat stable
	 */
	
	Dilem[] simulations;
	AnalyseDonn�es[] data;
	
	public void run() {
		//nombres de simulations
		int nb_simu=7;
		
		//pr�cision que l'on souhaite avoir pour la simulation
		//pour mieux comprendre comment cela impacte le programme
		//Voici la condition a respecter pour etre considerer sur une it�ration stable :
		//Math.abs(data[i].getC()-data[i+1].getC())<=Math.pow(10, -precision)
		int[] precision= generation_para_constant(4,nb_simu);
		//nombre de tours stock�e par les objets afin de d�terminer si la simulation n'est pas dans un �tat �ph�m�re
		int[] nb_tours= generation_para_constant(3,nb_simu);
		
		//on ini le temps d'attente
		tps_en_ms=100;
		
		//on initialise ici les param�tres des simulations explicitements
		float[] exigences_b= generation_para_avec_pas_float(1.75f,nb_simu,0.05f);
		int[] largeurs= generation_para_constant(200,nb_simu);
		int[] hauteurs= generation_para_constant(200,nb_simu);
		int[] algo_gene= generation_para_constant(1,nb_simu);
		//ce parametre ne s'applique si on choisi l'algo de gene n�1
		int[] pourcentages_traitres= generation_para_constant(10,nb_simu);
		
		//on initialise le tableau des parametres des simulations
		ParametresCanvas[] parasCanvas=ini_parametres_canvas(exigences_b,largeurs,hauteurs,algo_gene,pourcentages_traitres);
		//les simulations et des objets d'analyse de Donn�es
		simulations=new Dilem[parasCanvas.length];
		data=new AnalyseDonn�es[parasCanvas.length];
				
		for (int i=0;i<parasCanvas.length;i++) {
			simulations[i]=new Dilem(parasCanvas[i]);
			data[i]=new AnalyseDonn�es(nb_tours[i],parasCanvas[i].getGains());
			data[i].setPrecision(precision[i]);
			//test
				if(parasCanvas[i].getAlgo_gene()==1) {
					data[i].setNb_traitres(parasCanvas[i].getPourcentage());
				}
		}
		System.out.println("off");
		//cette varaible est le temps que l'on donne au simulations avant l'observation
		//cela permet de ne pas classifier une simu non stable mais pas assez perturb�e pour avoir un impact sur C
		//de se d�velloper
		int nb_tours_off=50;
		
		for(int i=0;i<nb_tours_off;i++) {
			for(int j=0;j<simulations.length;j++) {
				simulations[j].tour();
			}
		}
		System.out.println("run true");
		double nb_tours_b=0;
		//conditon d'arret de la boucle:
		//les simulations ont toutes atteints un �tat stable
		//ou on a atteint le nombres de tours max allou�
		int nb_tours_max=1000;
		//ini du tableaux de booleen pour savoir si on doit traiter ou non une simulation
		//cela permet de clarifier les r�sultats
		boolean[] stables=new boolean[simulations.length];
		for(int i=0;i<stables.length;i++) {
			stables[i]=false;
		}
		boolean toutes_stables=simu_stables(stables);
		
		while(!toutes_stables&&nb_tours_b<nb_tours_max) {
			for(int i=0;i<simulations.length;i++) {
				//on ex�cute que les simulations instables
				if(!(stables[i])) {
					transfert_donnees(i);
					stables[i]=affiche_console(simulations[i],data[i]);
				}
			}
			nb_tours_b++;
			if(nb_tours_b%100==0) {
				System.out.println(nb_tours_b);
				System.out.println();
			}
			toutes_stables=simu_stables(stables);
		}
		System.out.println("nombres de tours totals"+nb_tours_b);
		
		Donnees[][] data_simu=new Donnees[1][data.length];
		
		for(int i=0;i<simulations.length;i++) {
			//on copie les derni�res donn�es dans un graphique
			data_simu[0][i]=data[i].getLast();
			
			/*//on ex�cute que les simulations instables
			if(!(stables[i])) {
				System.out.println("Dernier C:"+data[i].getLast().getC());
				System.out.println("b="+(float)((float)simulations[i].getRef().getGains()[1][0]/(float)simulations[i].getRef().getGains()[0][0]));
				if(simulations[i].getRef().getAlgo_gene()==1) {
					System.out.println("pourcentages de traitres (environ):"+simulations[i].getRef().getPourcentage());
				}
				System.out.println();
			}*/
		}
		
		//on ini les param�tres du graphique
		int[] largeurs_G = {500};
		int[] hauteurs_G = {500};
		int[] varnums = {1};
		//titres des diff�rents axes sur les graphiques
		String[] axes_x=duplication_string("pourcentage de tra�tres",1);
		String[] axes_y=duplication_string("C",1);
		String[] Titres_graph=duplication_string("C en fonction du pourcentage de Tra�tres",1);
		//on ini le tableau de parametres graphiques
		ParametresGraphique[] parasGraph=ini_parametres_graphique(largeurs_G,hauteurs_G,varnums,axes_x,axes_y,Titres_graph);
		
		//on ini le graphique et son image
		ImageGraphiqueSpontannee img=new ImageGraphiqueSpontannee(parasGraph[0],2);
		
		GraphiqueSpontannee graph=new GraphiqueSpontannee(parasGraph[0]);
		
		Component[] compo=new Component[1];
		
		compo[0]=graph;
		//on transmet les donn�es � l'image et on repaint le graph
		img.traitement_donnees(data_simu);
		
		graph.setExtremums_x(img.getExtremums_x());
		
		graph.setImage(img);
		
		graph.repaint();
		
		Fenetre F = new Fenetre(compo);
	}
	
	protected void transfert_donnees(int i) {
		//dans cette fonction on doit actualiser les simulations et transf�rer les grilles pour analyse
		//tout en respectant si les grilles sont stables ou pas via i
		simulations[i].tour();
		data[i].calculDonnees(simulations[i].getGrille());
	}
	//on definie la fonction pour contenter l'h�ritage
	protected void transfert_donnees() {}
	
	private boolean affiche_console(Dilem simu,AnalyseDonn�es data) {
		/*
		 * Fonction qui prend en entr�e:
		 * 		-simu:la somulation � v�rifier
		 * 		-data: l'objet qui analyse la simulation
		 * et doit afficher des caract�ristiques de la simulation pour indentification si elle est stable
		 */
		
		boolean stable=data.simu_stable();
		
		/*if(stable) {
			//on affiche les param�tres int�r�sants
			System.out.println("La Simulation suivante est stable:");
			System.out.println("le pourcentage de croyants tend vers:"+data.getLast().getC());
			System.out.println("b="+(float)((float)simu.getRef().getGains()[1][0]/(float)simu.getRef().getGains()[0][0]));
			System.out.println("algo de generation "+simu.getRef().getAlgo_gene());
			//on affiche le pourcentage seulement si l'algorithme le prend en compte
			if(simu.getRef().getAlgo_gene()==1) {
				System.out.println("pourcentages de traitres (environ):"+simu.getRef().getPourcentage());
			}
			System.out.println();
		}*/
		return stable;
	}
	
	private boolean simu_stables(boolean[] simu_stabiliter) {
		boolean stables=true;
		
		for(int i=0;i<simu_stabiliter.length;i++) {
			if(!(simu_stabiliter[i])) {
				stables=false;
			}
		}
		
		return stables;
	}
}
