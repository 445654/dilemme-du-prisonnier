import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Arrays;

public class ImageGraphiqueTempReel extends ImageAbs{
	/*
	 * Classe qui as pour but de cr�e une image qui va g�rer le niveau graphique
	 * d'un graphique
	 */
	//nombre de tours passer (permet de selectionner le bon pixel en x)
	private int nbTours=0;
	
	ImageGraphiqueTempReel(ParametresGraphique G){
		this.varNum=G.getVarNum();
		this.HAUTEUR=G.getHAUTEUR();
		this.LARGEUR=G.getLARGEUR();
		
		image=new BufferedImage(LARGEUR, HAUTEUR,BufferedImage.TYPE_INT_RGB);
		
		graphic=(Graphics2D) image.getGraphics();
		resetGraphique();
	}
	
	public void refresh(Donnees[] donnees_du_tour) {
		//fonction qui dessine les pointsdu tour sur l'image
		for(int i=0;i<donnees_du_tour.length;i++) {
			float data=extractData(donnees_du_tour[i],varNum);
			
			int[] coord_point=recitfication_coord(data);
			
			dessiner_pts(coord_point,Color.BLACK);
			
			nbTours++;
		}
	}
	private int[] recitfication_coord(float coord_y_d) {
		/*fonction qui doit rectifier les coordonn�es qui sont dans un repere
		 * orthonorm� 'normal' vers le repere de l'image (0,0 en haut � gauche)
		 * on as pas besoin de la coordonn�es en x car cela sera d�pendant du nb de tours
		 * coord_y_d est un flottant compris entre 0 et 1!
		 */
		//on transforme la variable en entier
		int coord_y = (int) Math.round(coord_y_d*HAUTEUR);
		
		int[] coord_rec = new int[2];
		//coordonn�es x
		coord_rec[0]=nbTours;
		//coordonn�es y
		coord_rec[1]=HAUTEUR-coord_y;
		
		return coord_rec;
	}
	
	
}
