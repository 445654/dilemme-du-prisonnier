import java.awt.*;

public abstract class GraphiqueAbs extends Canvas{
	//taille du canvas
	protected int HAUTEUR=0;
	protected int LARGEUR=0;
	//taille de la l�gende dans les diff�rentes direction
	//ces tailles sont a determiner selon ce que l'on veut faire
	protected int taille_legende_haut=15;
	protected int taille_legende_bas=15;
	protected int taille_legende_gauche=20;
	protected int taille_legende_droite=0;
	//param�tres du graphiques
	protected ParametresGraphique p;
	
	//points de d�part d'affichage de l'image
	protected int depart_image_x=0;
	protected int depart_image_y=0;
	//contexte graphique du canvas
	public Graphics2D g;
	
	//image que l'on affiche dans le graphique
	public ImageAbs image;
	
	public abstract void paint(Graphics G);
	protected abstract void legende(Graphics G);
	
	//getters et setters
	public ImageAbs getImage() {
		return image;
	}

	public void setImage(ImageAbs image) {
		this.image = image;
	}
}
