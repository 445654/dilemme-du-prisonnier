
public abstract class DilemAbs {
	
	//fonctions a d�finir
	public abstract void tour();
	
	public abstract void generation();
	
	protected abstract PrisonnierOpportuniste[] voisins_proches_communiquant(int x,int y);
	
	
	//variables communes a tous les h�ritiers
	
	//matrice des prisonniers
	public PrisonnierAbs grille[][];
	//diff�rents comportements possibles
	protected int CROYANT = 0;
	protected int TRAITRE =1;
	//param�tres de la simulation
	protected ParametresCanvas ref;
		
	
	//getters et setters
	public PrisonnierAbs[][] getGrille() {
		return grille;
	}

	public void setGrille(PrisonnierOpportuniste[][] grille) {
		this.grille = grille;
	}

	public ParametresCanvas getRef() {
		return ref;
	}

	public void setRef(ParametresCanvas ref) {
		this.ref = ref;
	}
}
