
public class ParametresCanvas {
	/*
	 * Classe qui as pour but de contenir les param�tres n�cessaires � la simulation/
	 * la classe Dilem
	 *
	 * */
	//taille de la matrice des prisonniers
	public int HAUTEUR=0;
	public int LARGEUR=0;
	//matrice des gains
	public int [][]gains;
	//num�ro de l'algorithme de changement de comportement
	public int algo_chang=0;
	//version de l'algo de g�n�ration que l'on veut
	public int algo_gene=0;
	//pourcentage de traitres pour la gene al�atoire
	public int pourcentage=0;
	ParametresCanvas(){
	}
	
	ParametresCanvas(int H,int L,int[][] G,int algo,int algo_gene,int pourcentage){
		HAUTEUR=H;
		LARGEUR=L;
		gains=G;
		algo_chang=algo;
		this.algo_gene=algo_gene;
		this.pourcentage=pourcentage;
	}
	
	public int getAlgo_gene() {
		return algo_gene;
	}

	public int getAlgo_chang() {
		return algo_chang;
	}
	public void setAlgo_chang(int algo_chang) {
		this.algo_chang = algo_chang;
	}
	public int getHAUTEUR() {
		return HAUTEUR;
	}
	public void setHAUTEUR(int hAUTEUR) {
		HAUTEUR = hAUTEUR;
	}
	public int getLARGEUR() {
		return LARGEUR;
	}
	public void setLARGEUR(int lARGEUR) {
		LARGEUR = lARGEUR;
	}
	public int[][] getGains() {
		return gains;
	}
	public void setGains(int[][] gains) {
		this.gains = gains;
	}

	public int getPourcentage() {
		return pourcentage;
	}
	
}
