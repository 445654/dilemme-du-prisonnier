import java.awt.*;

public class GraphiqueTempReel extends GraphiqueAbs{
	/*
	 * Classe qui doit:
	 * 		-tracer un graphique pour une ou plusieurs variables de diff�rentes simulations
	 * 		-faire une l�gende compr�hensible
	 */
	GraphiqueTempReel(ParametresGraphique P){
		this.HAUTEUR=P.getHAUTEUR()+taille_legende_haut+taille_legende_bas;
		this.LARGEUR=P.getLARGEUR()+taille_legende_gauche+taille_legende_droite;
		g=(Graphics2D) this.getGraphics();
		
		image=new ImageGraphiqueTempReel(P);
		p=P;
	}
	
	public void paint(Graphics G) {
		legende(G);
		G.drawImage(image.getImage(),taille_legende_gauche,taille_legende_haut,this);
	}
	protected void legende(Graphics G) {
		//fonction qui doit dessiner la legende � chaque tour aux endroits sp�cifi�es
		//limite de l'image
		G.drawLine(taille_legende_gauche-1,taille_legende_haut,taille_legende_gauche-1,HAUTEUR-taille_legende_bas);
		G.drawLine(taille_legende_gauche-1, HAUTEUR-taille_legende_bas, LARGEUR-taille_legende_droite, HAUTEUR-taille_legende_bas);
		//on dessine le titre de l'axe x au milieu du graphique
		G.drawString(p.getAxe_x(), ((LARGEUR-taille_legende_droite+taille_legende_gauche)/2)-(p.getAxe_x().length()*(5/2)), HAUTEUR);
		//on dessine le titre de l'axe y au milieu du graphique
		G.drawString(p.getAxe_y(), 5, ((HAUTEUR-taille_legende_haut+taille_legende_bas)/2)-(p.getAxe_y().length()*(5/2)));
		//on dessine les extremums de l'axe x
		G.drawString("0",taille_legende_gauche,HAUTEUR);
		G.drawString(String.valueOf(LARGEUR-(taille_legende_gauche+taille_legende_droite)),LARGEUR-taille_legende_droite-10,HAUTEUR);
		//on dessine les extremums de l'axe y
		G.drawString("1",10,10);
		G.drawString("0",10,HAUTEUR-15);
		//on dessine le Titre
		G.drawString(p.getTitre_graph(), ((LARGEUR-taille_legende_droite+taille_legende_gauche)/2)-(p.getTitre_graph().length()*(5/2)), 10);
	}
}
