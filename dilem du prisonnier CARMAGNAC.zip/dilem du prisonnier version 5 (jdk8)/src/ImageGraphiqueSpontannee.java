import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageGraphiqueSpontannee extends ImageAbs{
	/*
	 * Classe qui as pour but de dessiner plusieurs courbes � partir de coordonn�es
	 * envoy�es d'un coup
	 */
	//les extremums ne sont pas forc�ment entre 0 et X donc on doit les stock�es pour rectifier les coordonn�es
	public float[] extremums_x;
	//variable que l'on exploite en x
	public int varNum_x=0;
	
	ImageGraphiqueSpontannee(ParametresGraphique G,int varNum2){
		this.varNum=G.getVarNum();
		this.HAUTEUR=G.getHAUTEUR();
		this.LARGEUR=G.getLARGEUR();
		
		image=new BufferedImage(LARGEUR, HAUTEUR,BufferedImage.TYPE_INT_RGB);
		
		graphic=(Graphics2D) image.getGraphics();
		resetGraphique();
		
		varNum_x=varNum2;
	}
	
	public void traitement_donnees(Donnees[][] setsDonnees) {
		/*
		 * Fonction qui doit tracer les diff�rentes courbes des diff�rents sets de donn�es
		 */
		resetGraphique();
		identification_extremums(setsDonnees);
		
		Color[] couleurs=couleursCourbes(setsDonnees.length);
		
		for(int i=0;i<setsDonnees.length;i++) {
			traceSet(setsDonnees[i],couleurs[i]);
		}
	}
	
	private void identification_extremums(Donnees[][] setsDonnees) {
		/*
		 * Fonction qui as pour but de d�terminer les extremums en x car en y on le rappel les variables
		 * sont comprises entre 0 et 1
		 */
		float[] variable_set;
		float[] extremums=new float[setsDonnees.length*2];
		
		int j=0;
		
		for(int i=0;i<setsDonnees.length;i++) {
			//on reset le buffer
			variable_set= new float[setsDonnees[i].length];
			//on r�colte les donn�es
			for(int w=0;w<setsDonnees[i].length;w++) {
				variable_set[w]=extractData(setsDonnees[i][w],varNum_x);
			}
			//on r�colte les extremums
			float[] extremes=floatTabMinMax(variable_set);
			//on les stockes dans le tableaux des extr�mes
			extremums[j]=extremes[0];
			extremums[j+1]=extremes[1];
			
			j+=2;
		}
		//on recoltes les extr�mes des extr�mes
		extremums_x=floatTabMinMax(extremums);
		
	}
	
	private void traceSet(Donnees[] set,Color couleur) {
		/*
		 * Fonction qui doit tracer un set de donn�es sp�cifiques
		 */
		//coordonn�es avant rectification
		//float[] coord_base;
		
		//coordonn�es rectifi�es
		int[] coord_rec;
		
		for(int i=0;i<set.length;i++) {
			//System.out.println("donn�es:"+i+" C:"+set[i].getC()+" B:"+extractData(set[i],varNum_x));
			float[] coord_base= {extractData(set[i],varNum_x),extractData(set[i],varNum)};
			
			coord_rec=rectification_coord(coord_base[0],coord_base[1]);
			
			dessiner_pts(coord_rec,couleur);
		}
		
	}
	
	private float[] floatTabMinMax(float[] tab) {
		/*
		 * Fonction qui doit renvoyer le minimum et le maximum d'un tableau de flottans
		 * min est en position 0 et max en position 1
		 */
		float[] miniMaxi= {tab[0],tab[0]};
		
		for(int i=0;i<tab.length;i++) {
			if(tab[i]<miniMaxi[0]) {
				miniMaxi[0]=tab[i];
			}
			
			if(tab[i]>miniMaxi[1]) {
				miniMaxi[1]=tab[i];
			}
		}
		
		return miniMaxi;
	}
	
	private int[] rectification_coord(float coord_x,float coord_y) {
		/*fonction qui doit rectifier les coordonn�es qui sont dans un repere
		 * orthonorm� 'normal' vers le repere de l'image (0,0 en haut � gauche)
		 * 
		 * coord_y et coord_x sont des flottant compris entre 0 et 1!
		 */
		int[] coord_rec = new int[2];
		
		//on rectifier les coordonn�es avec les formules suivantes
		coord_rec[0]=Math.round((coord_x-extremums_x[0])/(extremums_x[1]-extremums_x[0])*LARGEUR);
		coord_rec[1]=Math.round(HAUTEUR-coord_y*HAUTEUR);
		
		return coord_rec;
	}
	//getters et setters

	public float[] getExtremums_x() {
		return extremums_x;
	}
	
}
