
public class Dilem extends DilemAbs{
	/*Classe qui as pour but de simuler un Dilem du prisonnier
	 * sur une grille 2D communicante (pas de bords)
	 * TODO:
	 * -cr�e une grille de prisonnier et la g�n�r�e correctement
	 * -simuler un tour de la simulation:
	 * 		-Chaque prisonnier doit pouvoir jouer contre ces voisins
	 * 		-(A faire plutard)actualiser les historiques des prisonniers
	 * 		-on doit changer les comportements des prisonniers en fonction de leurs voisins
	 * -cr�e une pause pour la simulation (pour permettre � l'humain de regarder la simulation)
	 * -retourner un tableau d'entiers indiquant les �tats qui sont affichables
	 */
	
	public Dilem(ParametresCanvas P){
		//fonction qui initialise les param�tres
		ref=P;
		//on initialise la grille
		grille=new PrisonnierOpportuniste[ref.getLARGEUR()][ref.getHAUTEUR()];
		
		//on g�n�re la grille de prisonniers
		generation();
	}
	
	public void tour() {
		/*Fonction qui actualise la grille des prisonniers une fois 
		 * */
		//on calcul les scores de tout les prisonniers
		calcul_grille_score();
		//on calcule les comportments suivants
		changement_comportement_global();
		//on actualise les comportements
		actualisation_comportement();
	}
	
	public void generation() {
		/*
		 * Fonction qui va g�n�r� la grille
		 * 
		 */

		//on initialise tout les prisonniers de grille et de la grille
		for(int x=0;x<ref.getLARGEUR();x++) {
			for(int y=0;y<ref.getHAUTEUR();y++) {
				grille[x][y]=new PrisonnierOpportuniste();
				grille[x][y].setComportement(CROYANT);
			}
		}
		//on g�n�re diff�ramment suivant les param�tres
		switch(ref.getAlgo_gene()){
			case 0:
				generation_milieu_traitre();
			break;
			case 1:
				generation_aleatoire_traitre(ref.getPourcentage());
			break;
		}
	}
	
	private void generation_milieu_traitre() {
		//comme les prisonnier sont tous des croyants de base on change juste le comportement de celui du milieu
		int [] coord_milieu= {ref.getLARGEUR()/2,ref.getHAUTEUR()/2};
		grille[coord_milieu[0]][coord_milieu[1]].setComportement(TRAITRE);
	}
	
	private void generation_aleatoire_traitre(float pourcentage_traitrise) {
		/*
		 * Fonction qui doit g�n�rer une grille al�atoirement
		 */
		if(pourcentage_traitrise<=50) {
			generation_aleatoire_comportement(TRAITRE,pourcentage_traitrise);
		}
		else {
			//si on as plus de 50% de traitres � mettre
			//on choisit de mettre la grille qu'avec des traitres et des r�partirs les croyants al�atoirement
			for(int x=0;x<ref.getLARGEUR();x++) {
				for(int y=0;y<ref.getHAUTEUR();y++) {
					grille[x][y].setComportement(TRAITRE);
				}
			}
			
			generation_aleatoire_comportement(CROYANT,100-pourcentage_traitrise);
		}
	}
	
	private void generation_aleatoire_comportement(int comportement,float pourcentage) {
		/*
		 * Fonction qui doit al�atoirement plac�e des comportements sur la grille jusqu'� atteindre le pourcentage voulu
		 *On va choisir des prisonniers au hasard et v�rifi�es leurs comportements si ils ne sont pas au bon comportement
		 *on leur donne le bon
		 */
		long nombrePrisonniers=(long)(ref.getHAUTEUR()*ref.getLARGEUR()*(float)(pourcentage/100));
		
		int[] coord_prisonnier=new int[2];
		
		while(nombrePrisonniers>=0) {
			//on genere des coords al�atoires
			coord_prisonnier[0]=Math.round((float)Math.random()*(ref.getLARGEUR()-1));
			coord_prisonnier[1]=Math.round((float)Math.random()*(ref.getHAUTEUR()-1));
			
			if (grille[coord_prisonnier[0]][coord_prisonnier[1]].getComportement()!=comportement) {
				grille[coord_prisonnier[0]][coord_prisonnier[1]].setComportement(comportement);
				nombrePrisonniers--;
			}
		}
		
	}
	
	protected PrisonnierOpportuniste[] voisins_proches_communiquant(int x,int y) {
		//version espace communicant
		PrisonnierOpportuniste voisins[]=new PrisonnierOpportuniste[9];
		//coordonn�es possibles des voisins de la case
		int [][] coordonnees_theoriques= {{x+1,y-1},{x+1,y},{x+1,y+1},{x,y-1},{x,y},{x,y+1},{x-1,y-1},{x-1,y},{x-1,y+1}};
		
		int []coordonnees_rectifiees= {-1,-1};
		
		for(int i=0;i<voisins.length;i++) {
			voisins[i]=new PrisonnierOpportuniste();
			//on rectifie les coordonn�es qui sont peut �tre �ronn�es
			//si elle ne le sont pas on s'en fiche
			coordonnees_rectifiees=rectification_coordonnees(coordonnees_theoriques[i]);
			//on remplace l'objet initialiser par sa version sur la grille
			voisins[i].setScore(grille[coordonnees_rectifiees[0]][coordonnees_rectifiees[1]].getScore());
			voisins[i].setComportement(grille[coordonnees_rectifiees[0]][coordonnees_rectifiees[1]].getComportement());
			
		} 
		
		return voisins;
	}
	
	
	private int[] rectification_coordonnees(int[] coordonnees) {
		//on part du principe que les coordonn�es sont �crites de la mani�re
		//suivante: (x,y)
		int[] coordonnees_rectifiees= {0,0};
		//on rectifie les coordonn�es en x
		if(coordonnees[0]>=ref.getLARGEUR()) {
			coordonnees_rectifiees[0]=0;
		}
		else if(coordonnees[0]<0) {
			coordonnees_rectifiees[0]=ref.getLARGEUR()-1;
		}
		else {
			coordonnees_rectifiees[0]=coordonnees[0];
		}
		//on rectifie les coordonn�es en y
		if(coordonnees[1]>=ref.getHAUTEUR()) {
			coordonnees_rectifiees[1]=0;
		}
		else if(coordonnees[1]<0) {
			coordonnees_rectifiees[1]=ref.getHAUTEUR()-1;
		}
		else {
			coordonnees_rectifiees[1]=coordonnees[1];
		}
		
		return coordonnees_rectifiees;
	}
	
	private int calcul_score(PrisonnierAbs Joueur,PrisonnierAbs[] voisins_du_joueur) {
		//Fonction qui va calculer le score d'un prisonnier donn� (Joueur)
		
		//score du prisonnier
		int score=0;
		//on initialise les choix des diff�rents joueurs
		int choixJoueur=-1;
		int choixVoisins=-1;
		//on initialise la matrice des gains qui nous servira de r�f�rence
		int [][] gains=ref.getGains();
		
		choixJoueur=Joueur.Choix();
		for(int i=0;i<voisins_du_joueur.length;i++) {
			choixVoisins=voisins_du_joueur[i].Choix();
			score+=gains[choixJoueur][choixVoisins];
		}
		
		//on renvoie le score du prisonnier
		return score;
	}
	
	private void calcul_grille_score() {
		/*
		 * Fonction qui calcule le score pour toute la grille
		 */
		//on initialise les diff�rentes variables
		PrisonnierOpportuniste[] voisins;
		PrisonnierOpportuniste joueur;
		
		for(int x=0;x<ref.getLARGEUR();x++) {
			for(int y=0;y<ref.getHAUTEUR();y++) {
				/*//on initialise le joueur actuel
				joueur=grille[x][y];*/
				//on trouve les voisins
				voisins=voisins_proches_communiquant(x,y);
				//on calcul le score joueur
				grille[x][y].setScore(calcul_score(grille[x][y],voisins));
			}
		}
	}
	
	private void changement_comportement_global() {
		/*
		 * Fonction qui met au point les strat�gies de n+1 en fonction des voisins
		 */
		//on initialise les diff�rentes variables
		PrisonnierAbs[] voisins;
		PrisonnierAbs joueur;
		
		
		for(int x=0;x<ref.getLARGEUR();x++) {
			for(int y=0;y<ref.getHAUTEUR();y++) {
				//on initialise le joueur actuel
				joueur=grille[x][y];
				//on trouve les voisins
				voisins=voisins_proches_communiquant(x,y);
				//on met au point la prochaine strat�gie
				joueur.stratMaj(voisins);
			}
		}
		

	}
	
	private void actualisation_comportement() {
		for(int x=0;x<ref.getLARGEUR();x++) {
			for(int y=0;y<ref.getHAUTEUR();y++) {
				grille[x][y].actualisationStrat();
			}
		}
	}
	
	public int [][] toTab() {
		//fonction qui a pour but de renvoyer un tableau d'entier d�crivant l'�tat de la grille
		int [][]resultat =new int[2*ref.LARGEUR][ref.HAUTEUR];
		//on parcours le tableau
		for (int x=0;x<resultat.length;x+=2) {
			for(int y=0;y<resultat[0].length;y++) {
				//on fait correspondre le comportement de la grille a la case de resultat
				//on ajoute aussi le score dans la case d'a cot� pour v�rifier la simulation
				resultat[x][y]=grille[x/2][y].getComportement();
				resultat[x+1][y]=(int) grille[x/2][y].getScore();
			}
		}
		
		return resultat;
	}
	

}
