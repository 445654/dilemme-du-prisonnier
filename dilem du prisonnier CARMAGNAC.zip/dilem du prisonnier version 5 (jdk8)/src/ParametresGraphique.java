
public class ParametresGraphique {
	/*
	 * Classe qui contient les param�tres d'un graphique
	 */
	//hauteur et largeur allouer au graphique
	public int HAUTEUR;
	public int LARGEUR;
	//num�ro de la variable a observer
	public int varNum;
	//titres des diff�rents axes etc
	public String axe_x;
	public String axe_y;
	public String Titre_graph;
	
	ParametresGraphique(){}
	
	ParametresGraphique(int hauteur,int largeur,int varnum,String axe_x,String axe_y,String Titre){
		HAUTEUR=hauteur;
		LARGEUR=largeur;
		varNum=varnum;
		this.axe_x=axe_x;
		this.axe_y=axe_y;
		this.Titre_graph=Titre;
	}
	
	//getters et setters
	public int getHAUTEUR() {
		return HAUTEUR;
	}
	public void setHAUTEUR(int hAUTEUR) {
		HAUTEUR = hAUTEUR;
	}

	public void setLARGEUR(int lARGEUR) {
		LARGEUR = lARGEUR;
	}

	public void setVarNum(int varNum) {
		this.varNum = varNum;
	}

	public int getLARGEUR() {
		return LARGEUR;
	}
	public int getVarNum() {
		return varNum;
	}

	public String getAxe_x() {
		return axe_x;
	}

	public void setAxe_x(String axe_x) {
		this.axe_x = String.valueOf(axe_x);
	}

	public String getAxe_y() {
		return axe_y;
	}

	public void setAxe_y(String axe_y) {
		this.axe_y = String.valueOf(axe_y);
	}

	public String getTitre_graph() {
		return Titre_graph;
	}

	public void setTitre_graph(String titre_graph) {
		Titre_graph = titre_graph;
	}

	
	
}
