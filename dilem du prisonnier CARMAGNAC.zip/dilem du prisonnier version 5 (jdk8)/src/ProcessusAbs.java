import java.awt.*;

public abstract class ProcessusAbs extends Thread{
	//variables communes aux h�ritiers
	
	protected int tps_en_ms;
	
	//fonctions pr�d�finies pour les h�riti�s
	
	protected ParametresCanvas[] ini_parametres_canvas(float[] exigences_b,int[] largeurs,int[] hauteurs,int[] alog_gene,int[] pourcentages) {
		/*fonction qui doit initialiser les diff�rents param�tres des diff�rentes simulations
		elle prend en entr�e: les diff�rents b,les diff�rentes hauteurs et largeurs, la version voulue,l'algo de generation
		et sort un tableau de param�tres satisfaisant les exigences
		*/
		//on ini le bon nombre de param�tres
		ParametresCanvas[] paras=new ParametresCanvas[exigences_b.length];
		
		for(int i=0;i<paras.length;i++) {
			paras[i]=new ParametresCanvas();
			paras[i]=ini_para_individuel_canvas(exigences_b[i],largeurs[i],hauteurs[i],alog_gene[i],pourcentages[i]);
		}
		
		return paras;
	}
	
	protected ParametresCanvas ini_para_individuel_canvas(float exigence_b,int largeur,int hauteur,int algo_gene,int pourcentage) {
		//on clarifie les r�compenses
		//le joueur selectionne le premier para du tableau
		int recompense_coop_totale=100;
		int recompense_trahison_totale=0;
		int recompense_trahison_reussite=Math.round(100*exigence_b);
		int recompense_coop_echec=0;
		//on initialise l'image et les param�tres
		int[][] matrice_gains = {{recompense_coop_totale,recompense_coop_echec},{recompense_trahison_reussite,recompense_trahison_totale}};
		
		//on initialise les param�tres de la simulation
		ParametresCanvas para=new ParametresCanvas(hauteur,largeur,matrice_gains,0,algo_gene,pourcentage);
		
		return para;
	}
	
	
	protected ParametresGraphique[] ini_parametres_graphique(int[] largeurs,int[] hauteurs,int[] varnum,String[] axes_x,String[] axes_y,String[] Titres) {
		/*fonction qui doit initialiser les diff�rents param�tres des diff�rents graphiques
		elle prend en entr�e: les diff�rentes hauteurs et largeurs, les num�ros de variables a g�rers
		et sort un tableau de param�tres satisfaisant les exigences
		*/
		//on ini le bon nombre de param�tres
		ParametresGraphique[] paras=new ParametresGraphique[largeurs.length];
		
		for(int i=0;i<paras.length;i++) {
			paras[i]=new ParametresGraphique();
			paras[i]=ini_para_individuel_graphique(hauteurs[i],largeurs[i],varnum[i],axes_x[i],axes_y[i],Titres[i]);
		}
		
		return paras;
	}
	
	protected ParametresGraphique ini_para_individuel_graphique(int hauteur,int largeur,int varnum,String axe_x,String axe_y,String Titre) {
		//on initialise les param�tres du graphique
		ParametresGraphique para=new ParametresGraphique(hauteur,largeur,varnum,axe_x,axe_y,Titre);
		
		return para;
	}
	
	protected void sleep() {
		try {
			//on attend x milisecondes
			Thread.sleep(tps_en_ms);
		}catch (InterruptedException excp) {
			//on est CENSER g�rer l'exception ici mais on choisi de ne rien faire
		}
	}
	
	protected int[] generation_para_constant(int para,int nb) {
		/*
		 * Fonction qui doit g�n�r�e un tableau de longueur 'nb' avec comme contenu:
		 * {para,para,para etc}
		 */
		int[] tab_constant=new int[nb];
		
		for(int i=0;i<nb;i++) {
			tab_constant[i]=para;
		}
		
		return tab_constant;
	}
	
	protected int[] generation_para_avec_pas(int para,int nb,int pas) {
		/*
		 * Fonction qui doit g�n�r�e un tableau de longueur 'nb' avec comme contenu:
		 * {para+0,para+pas,para+2*pas etc}
		 */
		int[] tab_constant=new int[nb];
		
		for(int i=0;i<nb;i++) {
			tab_constant[i]=para+pas*i;
		}
		
		return tab_constant;
	}
	protected float[] generation_para_constant_float(float para,int nb) {
		/*
		 * Fonction qui doit g�n�r�e un tableau de longueur 'nb' avec comme contenu:
		 * {para,para,para etc}
		 */
		float[] tab_constant=new float[nb];
		
		for(int i=0;i<nb;i++) {
			tab_constant[i]=para;
		}
		
		return tab_constant;
	}
	
	protected float[] generation_para_avec_pas_float(float para,int nb,float pas) {
		/*
		 * Fonction qui doit g�n�r�e un tableau de longueur 'nb' avec comme contenu:
		 * {para+0,para+pas,para+2*pas etc}
		 */
		float[] tab_constant=new float[nb];
		
		for(int i=0;i<nb;i++) {
			tab_constant[i]=para+pas*i;
		}
		
		return tab_constant;
	}
	
	protected String[] duplication_string(String chaine,int nb) {
		//fonction qui as pour but de g�n�r�e un tableau de longeur nb qui contient que la chaine mise en entr�e
		String[] chaines=new String[nb];
		
		for(int i=0;i<chaines.length;i++) {
			chaines[i]=chaine;
		}
		
		return chaines;
		
	}
	
	//fonctions abstraites
	
	protected abstract void transfert_donnees();
	
	public abstract void run();
	
}
