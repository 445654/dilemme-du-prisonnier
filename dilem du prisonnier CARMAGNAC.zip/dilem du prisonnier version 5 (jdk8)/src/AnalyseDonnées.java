
public class AnalyseDonn�es {
	/*
	 * Classe qui as pour objectifs de:
	 * 		-transformer une grille de prisonniers en donn�es exploitables
	 * 		-pouvoir arrondir les donn�es
	 * 		-stock�e les donn�es de x tours (dans la m�moire vive)
	 * 		-renvoyer un objet Donn�es qui stockera les donn�es d'un tour
	 */
	//diff�rents comportements possibles
	private int CROYANT = 0;
	private int TRAITRE =1;
	//donn�es stock�ees lors des diff�rents tours
	private Donnees[] data;
	//pr�cision � donn�e pouur la fonction simu_stable (ini � 10^(-2))
	public int precision=2;
	//matrice des gains � mettre dans Donnees
	private int [][] gains;
	//nombres de croyants de base dans la simulation
	private int nb_traitres=0;
	
	AnalyseDonn�es(int nombres_de_tours_a_stockee,int[][] matrice_gains){
		//on a besoin de savoir la longueur du tableau data
		data=new Donnees[nombres_de_tours_a_stockee];
		//on initalise le tableau data de mani�re explicite
		for(int i=0;i<data.length;i++) {
			data[i]=new Donnees();
		}
		
		gains=matrice_gains;
	}
	
	public void calculDonnees(PrisonnierAbs[][] grille_actuel) {
		/*
		 * Fonction qui prend en entr�e:
		 * 		-la grille de prisonniers du tour actuel
		 * et traite la grille de telle sorte � ce que l'objet data[0]
		 * ai les donn�es les plus r�centes
		 */
		//variables utiles en g�n�ral
			long totalP=grille_actuel.length*grille_actuel[0].length;
		//probalit� d'avoir un Coop�rant
			float C=0;
			//variable aidant au calcul de la variable
			long nombreCroyants=0;
		
		for(int x=0;x<grille_actuel.length;x++) {
			for(int y=0;y<grille_actuel[0].length;y++) {
				//v�rifications utiles pour C
				if(grille_actuel[x][y].getComportement()==CROYANT) {
					nombreCroyants++;
				}
			}
		}
		//calcul des diff�rentes variables utiles
			//calcul de C
			C=(float) nombreCroyants/totalP;
		//on d�cale les objets pour �viter de garder des donn�es inutiles (�conomie de RAM)
		decalageData_un();
		//transfert des r�sultat dans l'objet Donn�es correspondant
		data[0].setC(C);
		data[0].setGains(gains);
		data[0].setNb_traitres(nb_traitres);
	}
	private void decalageData_un() {
		/*
		 * Fonction qui doit d�caler data de un cran (en supprimant le dernier objet)
		 */
		for(int i=data.length-1;0<i;i--) {
			data[i]=data[i-1];
		}
		data[0]=new Donnees();
	}
	
	public boolean simu_stable() {
		boolean stable=true;
		//condition: si la valeur absolue de la diff�rence entre les diff�rents C 
		//de toutes les donn�es est inf�rieure ou �gale a la pr�cision demander alors la simu est consid�rer stable
		float valeur_absolue=0;
		
		for(int i=0;i<data.length-1;i++) {
			valeur_absolue=Math.abs(data[i].getC()-data[i+1].getC());
			if(valeur_absolue>Math.pow(10, -precision)) {
				stable=false;
			}
			//System.out.println("V:"+valeur_absolue+" stable:"+stable);
		}
		
		return stable;
	}
	//fonction qui permet de r�cup�rer les donn�es les plus 'fraiches'
	public Donnees getLast() {
		Donnees Last = data[0];
		
		return Last;
	}
	//getters et setters
	public int getPrecision() {
		return precision;
	}

	public void setPrecision(int precision) {
		this.precision = precision;
	}

	public void setNb_traitres(int nb_traitres) {
		this.nb_traitres = nb_traitres;
	}
	
	
}
