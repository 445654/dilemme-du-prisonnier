import java.awt.*;
//Ceci importe la classe Scanner du package java.util
import java.util.Scanner; 

public class DessinsCanvas extends Canvas{
	/*
	 * Classe ou l'on va mettre l'image /dessiner
	 */
	//l'image que l'on va dessiner
	public ImageCanvas img;

	public int HAUTEUR;
	public int LARGEUR;
	DessinsCanvas(ParametresCanvas p){
		super();
		//on initialise les variables en fonction des param�tres
		img=new ImageCanvas(p);
		HAUTEUR=p.getHAUTEUR();
		LARGEUR=p.getLARGEUR();
		
	}
	
	public void paint(Graphics graph) {
		/*
		 * Fonction d�ja pr�sente dans le Canvas mais que l'on red�finie pour
		 * afficher l'image sur le canvas
		 */
		graph.drawImage(img.getImage(),0,0,this);
	}
	
	//getters et setters
	
	public int getHAUTEUR() {
		return HAUTEUR;
	}

	public ImageCanvas getImg() {
		return img;
	}

	public void setImg(ImageCanvas img) {
		this.img = img;
	}

	public void setHAUTEUR(int hAUTEUR) {
		HAUTEUR = hAUTEUR;
	}

	public int getLARGEUR() {
		return LARGEUR;
	}

	public void setLARGEUR(int lARGEUR) {
		LARGEUR = lARGEUR;
	}
	
}
