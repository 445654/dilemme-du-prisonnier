
public class PrisonnierSocial extends PrisonnierAbs{
	/*
	 * Classe qui as pour but de cr�er un prisonnier qui ne met pas � jour sa strat�gie car
	 * son comportement ne r�agira qu'au dernier coup de ses adversaires, il fera une moyenne
	 * et prendra le plus fr�quent
	 */
	
	PrisonnierSocial() {
		//on as rien besoin d'initialiser car le prisonnier est ind�pendant
	}
	
	public int Choix() {
		//on verifie le comportement du joueur et on applique les fonctions correspondantes
		if (comportement == CROYANT) {
			return choix_du_croyant();
		}
		else if (comportement==TRAITRE) {
			return choix_du_traitre();
		}
		else {
			return COOPERATION;
		}
	}
	public void stratMaj(PrisonnierAbs[] voisins) {
		int nb_croyants=0;
		int nb_traitres=0;
		//on compte le nombre de voisins croyants ou traitres
		for(int i=0;i<voisins.length;i++) {
			if (voisins[i].getComportement() == CROYANT) {
				nb_croyants++;
			}
			else{
				nb_traitres++;
			}
		}
		//si il y a plus de voisins croyants
		if(nb_croyants>nb_traitres) {
			this.comportement=CROYANT;
		}
		else {
			this.comportement=TRAITRE;
		}
	}
}
