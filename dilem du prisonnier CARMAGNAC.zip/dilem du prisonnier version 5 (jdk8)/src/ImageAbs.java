import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public abstract class ImageAbs {
	//Image que l'on manipule
	public BufferedImage image;
	//classe permettant d'interagir avec l'image
	public Graphics2D graphic;
	//hauteur et largeur de l'image
	protected int HAUTEUR=0;
	protected int LARGEUR=0;
	//num�ro de la variable � extraire
	protected int varNum=0;
	//coordonn�es du point pr�c�dent
	int[] dernieres_coords= {0,0};
	//param�tres de l'image de base que l'on garde pour les extremums
	
	
	protected void resetGraphique() {
		//fonction qui peint l'image en blanc afin de la rendre utilisable � nouveau
		graphic.setColor(Color.WHITE);
		graphic.fillRect(0, 0, LARGEUR, HAUTEUR);
		
		//graphic.setColor(Color.RED);
		//graphic.fillRect(0, 0, 50, 50);
	}
	
	protected void dessiner_pts(int[] coords,Color couleur) {
		graphic.setColor(couleur);
		graphic.fillRect(coords[0],coords[1],1,1);
		
		graphic.drawLine(dernieres_coords[0], dernieres_coords[1], coords[0], coords[1]);
		
		dernieres_coords=coords;
	}
	
	protected float extractData(Donnees data,int num) {
		//on devra ici faire au besoin un travail sur les donn�es pour les mettres entre 0 et 1
		//si on parle de donn�es qui sont affich�es en y
		float donnee_extraite=0;
		
		switch(num) {
			case 0:
				System.out.println("erreur aucune varaible s�lectionner");
			break;
			case 1:
				donnee_extraite=(float) data.getC();
			break;
			case 2:
				donnee_extraite=data.getB();
			break;
			case 3:
				donnee_extraite=(float)data.getNb_traitres();
			break;
		}
		
		return donnee_extraite;
	}
	protected Color[] couleursCourbes(int nb_couleurs_a_faire) {
		/*
		 * Fonction qui doit g�n�rer des couleurs sur tout l'espace rgb en fonction du nb de couleurs � faire
		 */
		int nb_rouges=(int) nb_couleurs_a_faire/3;
		int nb_verts=(int)nb_couleurs_a_faire/3;
		int nb_bleus=nb_couleurs_a_faire-nb_verts-nb_rouges;
		
		Color[] couleurs=new Color[nb_couleurs_a_faire];
		int i=0;
		
		for(int j=0;j<nb_rouges;j++) {
			couleurs[i]=new Color(255/(nb_rouges)*(j+1), 0, 0);
			i++;
		}
		
		for(int j=0;j<nb_verts;j++) {
			couleurs[i]=new Color(0,255/(nb_verts)*(j+1), 0);
			i++;
		}
		
		for(int j=0;j<nb_bleus;j++) {
			couleurs[i]=new Color(0,0,255/(nb_bleus)*(j+1));
			i++;
		}
		
		
		return couleurs;
	}
	
	//getters et setters

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

	public Graphics2D getGraphic() {
		return graphic;
	}

	public void setGraphic(Graphics2D graphic) {
		this.graphic = graphic;
	}

	public int getVarNum() {
		return varNum;
	}

	public void setVarNum(int varNum) {
		this.varNum = varNum;
	}
}
