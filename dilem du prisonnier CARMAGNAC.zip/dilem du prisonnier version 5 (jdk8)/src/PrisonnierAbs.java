
public abstract class PrisonnierAbs {
	/*
	 Abstraction de la Classe qui as pour but de simuler un individu dans le dilem du prisonnier
	 */
	//diff�rents comportements possibles
	protected int CROYANT = 0;
	protected int TRAITRE =1;
	//on initialise le COMPORTEMENT de base � croyant
	protected int comportement_futur=CROYANT;
	protected int comportement = CROYANT;
	protected int historique=CROYANT;
	//le score de notre prisonnier
	public float score=0;
	
	//les diff�rents choix possibles
	protected int COOPERATION=0;
	protected int TRAHISON=1;
	
	public abstract int Choix();
	
	public abstract void stratMaj(PrisonnierAbs[] voisins);
	
	public void actualisationStrat(){
		//fonction qui fait passer le comportement futur au comportement actuel
		historique=comportement;
		comportement=comportement_futur;
	}
	
	//fonctions g�n�riques set et get
	public void setComportement(int comportement) {
		this.historique=this.comportement;
		this.comportement = comportement;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public int getComportement() {
		return comportement;
	}

	public int getHistorique() {
		return historique;
	}

	public void setHistorique(int historique) {
		this.historique = historique;
	}

	public int getComportement_futur() {
		return comportement_futur;
	}
	//fonctions repr�sentant les diff�rents raisonnements basiques faits
	protected int choix_du_croyant() {
		return COOPERATION;
	}
	protected int choix_du_traitre() {
		return TRAHISON;
	}
}
