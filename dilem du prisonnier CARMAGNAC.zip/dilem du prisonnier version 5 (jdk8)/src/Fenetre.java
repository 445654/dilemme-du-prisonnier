import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Fenetre extends Frame implements WindowListener{
	/*
	 * Classe qui as pour but d'afficher touts les boutons et de g�rer
	 * les �v�nements utilisateurs
	 */
	//variables d�finissant la largeur et la hauteur de la FENETRE
	static int HAUTEUR=500;
	static int LARGEUR=500;
	//on initialise l'image
	Component[] composants;
	
	Fenetre(Component[] compo){
		//on initialise le tableaux de composants
		composants=compo;
		
		
		//fonction qui initialise la fenetre
		addWindowListener(this);
			
		setTitle("Fenetre");
		setSize(LARGEUR,HAUTEUR);
		setVisible(true);
		//on initialise les positions des composants
		this.setLayout(new GridLayout(composants.length/2, (composants.length/2)+1));
			
		for(int i=0;i<composants.length;i++) {
			//on ajoute les canvas
			this.add(composants[i],(char)i);//,BorderLayout.CENTER);
			this.pack();
		}
	}
	
	//Fonction � d�finir pour l'interface WindowListener
	//Fonction pour fermer la fen�tre
	public void windowClosing(WindowEvent e) {  
	    dispose();
	}  
	
	//fonction � avoir pour impl�menter WindowListener
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent arg0) {}
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
}
