import java.awt.*;
import java.awt.image.BufferedImage;

public class ImageCanvas{
	//Image que l'on manipule
	public BufferedImage image;
	//classe permettant d'interagir avec l'image
	public Graphics2D graphic;
	//on d�clare les param�tres de la simulation et la simulation
	public ParametresCanvas P;
	//diff�rents comportements possibles
	private int CROYANT = 0;
	private int TRAITRE = 1;
	
	ImageCanvas(ParametresCanvas p){
		//on initialise l'image
		image = new BufferedImage(p.getLARGEUR(), p.getHAUTEUR(),BufferedImage.TYPE_INT_RGB);
		graphic = (Graphics2D) image.getGraphics();
		//on initialise les param�tres de la simulation
		P=p;
	}
	
	public void refresh(PrisonnierAbs [][]grille) {
		//fonction qui rafraichi l'image
		
		//on parcours la grille de prisonnier
		for(int x=0;x<P.getLARGEUR();x++) {
			for(int y=0;y<P.getHAUTEUR();y++) {
				//on change le pixel x y de l'image en fonction du prisonnier
				graphic.setColor(couleurPrisonnier(grille[x][y]));
				graphic.fillRect(x, y, x, y);
			}
		}
	}
	
	private Color couleurPrisonnier(PrisonnierAbs P) {
		//Fonction qui va d�terminer la couleur d'un Prisonnier en fonction de son historique
		Color couleur=Color.WHITE;
		
		int comportement_actuel=P.getComportement();
		int comportement_passer=P.getHistorique();
		
		if(comportement_actuel==CROYANT && comportement_passer==CROYANT) {
			//si c'est un croyant depuis deux tours
			couleur=Color.BLUE;
		}
		else if (comportement_actuel==CROYANT && comportement_passer==TRAITRE) {
			//si c'est un traitre qui devient croyant
			couleur=Color.GREEN;
		}
		else if (comportement_actuel==TRAITRE && comportement_passer==CROYANT) {
			//si c'est un croyant qui devient un traitre
			couleur=Color.YELLOW;
		}
		else {
			//si c'est un traitre depuis deux tours
			couleur=Color.RED;
		}
		
		return couleur;
	}
	
	//getters et setters
	
	public BufferedImage getImage() {
		return image;
	}

	public Graphics2D getGraphic() {
		return graphic;
	}
	public void setGraphic(Graphics2D graphic) {
		this.graphic = graphic;
	}
	public void setImage(BufferedImage image) {
		this.image = image;
	}

	public ParametresCanvas getP() {
		return P;
	}

	public void setP(ParametresCanvas p) {
		P = p;
	}
	

}
